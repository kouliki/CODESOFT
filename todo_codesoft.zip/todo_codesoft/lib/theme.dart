import 'package:flutter/material.dart';
import 'package:todo_codesoft/colors/colors.dart';


bool isDark = false;
Color bgColor = tdBGColor;
Color iconColor = tdBlack;

void Change(){
  if(isDark == false){
    bgColor = tdBGColor;
    iconColor = tdBlack;
  }else{
    bgColor = tdBlack;
    iconColor = tdBGColor;
  }
}