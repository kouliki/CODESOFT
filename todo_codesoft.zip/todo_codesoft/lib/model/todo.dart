class Todo
{
  String? id;
  String? todotext;
  bool isDone;

  Todo({
    required this.id,
    required this.todotext,
    this.isDone=false,
});
  static List<Todo> todoList()
  {
    return[
      Todo(id: '01', todotext: 'Morning Exercise',isDone: true),
      Todo(id: '02', todotext: 'Doing Breakfast',isDone: true),
      Todo(id: '03', todotext: 'Studying'),
      Todo(id: '04', todotext: 'Doing lunch'),
      Todo(id: '05', todotext: 'playing'),
      Todo(id: '06', todotext: 'studying'),
      Todo(id: '07', todotext: 'Doing homework'),


    ];
  }


}