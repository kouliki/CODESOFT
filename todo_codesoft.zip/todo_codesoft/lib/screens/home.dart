import 'package:flutter/material.dart';
import 'package:todo_codesoft/colors/colors.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:todo_codesoft/widget/item.dart';
import 'package:todo_codesoft/model/todo.dart';

class Home extends StatefulWidget {
  Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final todosList=Todo.todoList();
  List<Todo>_foundTodo=[];
  ////  adding item ////

  final _todocontroller =TextEditingController();
  @override
  void initState() {  /// user will search over here
    // TODO: implement initState
    _foundTodo=todosList;
    super.initState();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppbar(),
      backgroundColor: tdBGColor,
      body: Stack(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            child: Column(
              children: [
                searchBar(),
                Expanded(child:
                ListView(
                  children: [
                    Container(
                      padding: EdgeInsets.only(top: 50,bottom: 30),
                      child:Text(
                        'Todolist',
                        style: GoogleFonts.alegreya(fontSize: 35,fontWeight: FontWeight.bold),

                      ),
                    ),

                   ///  todolist ////

                    for(Todo todoo in _foundTodo.reversed )
                   TodoItem(
                     todo: todoo,
                     ontapChanged: _handleToDo,
                     onDeleteItem: _deleteTodoItem,
                     onEditTodoItem: _editItem,

                   ),
                    // onDeleteItem: onDeleteItem,
                   ],

                ))

              ],
            ),

          ),
          Align(
            alignment: Alignment.bottomCenter,
            child:Row(
              children: [
                Expanded(
                    child:Container(
                      padding: EdgeInsets.symmetric(horizontal: 10.0),
                margin: EdgeInsets.only(
                  bottom: 20,
                  right: 20,
                  left:20,
                ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey,
                            offset: Offset(0.0,0.0),
                            blurRadius: 10.0,
                            spreadRadius: 0.0,

                        ),
                        ],
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: TextField(
                        controller: _todocontroller,
                        decoration: InputDecoration(

                          hintText: 'Add a new item',
                          contentPadding: EdgeInsets.symmetric(horizontal: 10.0),
                          border: InputBorder.none,


                        ),
                      ),

                )),

                Container(
                  margin: EdgeInsets.only(
                      bottom: 20,
                      right: 20,
                  ),
                  child: ElevatedButton(
                    child: Text('+',
                      style: TextStyle(fontSize: 40,),),
                    onPressed: (){
                      _addToDoItem(_todocontroller.text);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple,
                      elevation: 10,


                    ),
                  ),
                ),
              ],
            ) ,
          ),



        ],
      ),


    );
  }

  void _handleToDo(Todo todo){
    setState(() {
      todo.isDone=!todo.isDone;
    });
  }

  void _deleteTodoItem(String id){
    setState(() {
      todosList.removeWhere((item) => item.id == id);
    });

  }

  void _addToDoItem(String todo)
  {
    setState(() {
      todosList.add(
          Todo(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            todotext: todo,
      ));
    });

    _todocontroller .clear();

  }

  void _runfilter(String enteredKEyword)
  {
    List<Todo> results = [];
    if( enteredKEyword.isEmpty)
    {
      results=todosList;
    }
    else
    {
      results = todosList.where((item) => item.todotext!.toLowerCase().contains(enteredKEyword.toLowerCase())).toList();
    }
    setState(() {
      _foundTodo=results;
    });
  }

  void _editItem(Todo todo) {
    TextEditingController _editController = TextEditingController(text: todo.todotext);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Edit Task'),
          content: TextField(
            controller: _todocontroller, // Add the controller here
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (_editController.text.isNotEmpty) {
                  setState(() {
                    todo.todotext = _editController.text;
                  });
                }
                Navigator.pop(context);
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }

  void _updateTodoItem(String id, String newText) {
    setState(() {
      Todo todoToUpdate = todosList.firstWhere((item) => item.id == id);
      todoToUpdate.todotext = newText;
    });
  }



//////////  searchbar ////////////


  Widget searchBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: TextField(
          onChanged: (value)=>_runfilter(value), /// for searching
          decoration: InputDecoration(
            contentPadding: EdgeInsets.all(0),
            prefixIcon:
            Icon(Icons.search,
              color: tdBlack,
              size: 20,
            ),
            prefixIconConstraints: BoxConstraints(
              maxHeight: 20,
              minWidth: 25,
            ),
            border: InputBorder.none,
            hintText: 'search',
            hintStyle: TextStyle(
              color: tdGrey,
            ),
          )

      ),
    );
  }


///////////  Appbar /////////////////

  AppBar _buildAppbar() {
    return AppBar(
//       backgroundColor: Colors.transparent,
//       elevation: 0,
//       toolbarHeight: 85,
//       actions: [
//         Transform.scale(
//           scale: 1.2,
//           child: Switch.adaptive(
//               splashRadius: 0,
//               activeColor: tdBlack,
//               activeTrackColor: Colors.black26,
//               inactiveThumbImage: AssetImage('images/dark_mode.jpeg'),
//               activeThumbImage: AssetImage('images/light_mode.jpeg'),
//               value: isDark,
//               onChanged: (value) async {
//                 setState(() {
//                   isDark = value;
//                   // appData.toggleSwitch(value);
//                 });
//                 print(isDark);
//                 Change(); // Function call
//               }
//           ),
//         ),
//       ],
//     );
//   }
// }
      backgroundColor: tdBGColor,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(
            Icons.menu,
            color: tdBlack,
            size: 30,
          ),
          Text('Todo Task',
            style: GoogleFonts.acme(
                fontSize: 40,fontWeight: FontWeight.bold,color: Colors.deepPurple),
          ),
          Container(
            padding: EdgeInsets.zero,
            height: 50,
            width: 50,
            child: ClipOval(
              child: Image.asset('images/kouliki.jpg', fit: BoxFit.cover,
              ),
            ),
          )
        ],

      ),

    );
  }
}
